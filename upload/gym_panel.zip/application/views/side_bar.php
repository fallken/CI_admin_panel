<div class="col col-lg-2">
	<!--and here us the sidebar :) -->
	<div id="wrapper">

		<!-- Sidebar -->
		<div id="sidebar-wrapper">
			<ul class="sidebar-nav">
				<li class="sidebar-brand">

				</li>
				<li>
					<a href="<?php echo base_url(); ?>index.php/welcome/add_slide">اضافه سازی اسلاید</a>
				</li>
				<li>
					<a href="<?php echo base_url(); ?>index.php/welcome/add_post">ایجاد پست</a>
				</li>
				<li>
					<a href="<?php echo base_url(); ?>index.php/welcome/show/posts">تدوین پست ها</a>
				</li>
				<li>
					<a href="<?php echo base_url(); ?>index.php/welcome/add_cat">ایجاد دسته</a>
				</li>
				<li>
					<a href="#">ایمیل به کاربران</a>
				</li>
				<li>
					<a href="#">ایمیل به مربیان</a>
				</li>
				<li>
					<a href="#">ایمیل به صورت دسته جمعی</a>
				</li>
			</ul>
		</div></div></div>